package com.example.bookmanagement;

import javafx.beans.Observable;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class HelloController implements Initializable {
    @FXML
    private TextField idField;
    @FXML
    private TextField nameField;
    @FXML
    private TextField priceField;
    @FXML
    private TableView<Book> bookTableView;
    @FXML
    private TableColumn<Book, Number> idColumn;
    @FXML
    private TableColumn<Book, String> nameColumn;
    @FXML
    private TableColumn<Book, Number> priceColumn;

    ObservableList<Book> bookObservableList;


    @FXML
    protected void save() {
        int id = Integer.parseInt(idField.getText());
        String name = nameField.getText();
        double price = Double.parseDouble(priceField.getText());

        Book book = new Book(id, name, price);
        insert(book);
        bookObservableList.add(book);
        System.out.println(id + " " + name + " " + price);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        idColumn.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getId()));
        nameColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getName()));
        priceColumn.setCellValueFactory(c -> new SimpleDoubleProperty(c.getValue().getPrice()));

        bookObservableList = FXCollections.observableArrayList();
        bookTableView.setItems(bookObservableList);
        List<Book> bookList = list();
        bookObservableList.addAll(bookList);
    }

    private void insert(Book book) {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/bookdb", "root", "Why?");
            Statement statement = connection.createStatement();
            String query = "INSERT INTO book VALUES(" + book.getId() + ",'" + book.getName() + "'," + book.getPrice() + ")";
            statement.execute(query);


        } catch (SQLException e) {
            System.err.println("Failed to insert data into database");
        }
    }

    private void update(Book book) {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/bookdb", "root", "Why?");
            Statement statement = connection.createStatement();
            String query = "UPDATE book SET price=" + book.getPrice() + "WHERE id =" + book.getId() + ";";
            statement.execute(query);


        } catch (SQLException e) {
            System.err.println("Failed to insert data into database");
        }
        bookObservableList.clear();
        List<Book> bookList = list();
        bookObservableList.addAll(bookList);
    }

    private void delete(Book book) {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/bookdb", "root", "Why?");
            Statement statement = connection.createStatement();
            String query = "DELETE FROM book WHERE id =" + book.getId() + ";";
            statement.execute(query);


        } catch (SQLException e) {
            System.err.println("Failed to insert data into database");
        }
        bookObservableList.clear();
        List<Book> bookList = list();
        bookObservableList.addAll(bookList);
    }


    private List<Book> list() {
        List<Book> bookList = new ArrayList<>();

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/bookdb", "root", "Why?");
            Statement statement = connection.createStatement();
            String query = "SELECT * FROM book";
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                double price = resultSet.getDouble("price");

                Book book = new Book(id, name, price);
                bookList.add(book);
            }


        } catch (SQLException e) {
            System.err.println("Failed to get deta data into database");
        }
        return bookList;
    }

    @FXML
    public void updateBook() {
        int id = Integer.parseInt(idField.getText());
        String name = nameField.getText();
        double price = Double.parseDouble(priceField.getText());

        Book book = new Book(id, name, price);
        update(book);

    }

    @FXML
    public void deleteBook() {
        Book selectedBook = bookTableView.getSelectionModel().getSelectedItem();
        delete(selectedBook);

    }
 
}