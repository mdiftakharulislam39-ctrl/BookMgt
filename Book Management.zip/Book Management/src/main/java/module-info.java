module com.example.bookmanagement {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.bookmanagement to javafx.fxml;
    exports com.example.bookmanagement;
}